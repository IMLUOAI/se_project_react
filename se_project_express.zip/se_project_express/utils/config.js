
module.exports = {
  JWT_SECRET: process.env.JWT_SECRET || '66855fdbeb59e5e0524c779d',
};