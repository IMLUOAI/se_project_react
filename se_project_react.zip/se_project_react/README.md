## Sprint 14 (frontend & backend)

**Introduction of the WTWR APP**

_WTWR(What Is The Weather) is a self-study app-like project which was associated with the React study of chapter 11 from @Tripleten.tech. In this app, we designed the api live weather, clothing gallery, and +add clothing items functions, which could help you to choose your daily dress according to the live weather at that day. For exploring more details, you can download our app later from github later on._

_In this project, we have to hands on a few main parts of React. For intance, the useContext hook, useState hook, Routes && Router, and passing down Props from the parence to the children componenets logically. Finally, we still need to master how to correctly install the json-server to perform the project's api locally. On this point, it's totally differ the project's api from its previous status, which was rely on the internet's api data. Because of this, it's will be unable to deploy on Github to public later on._

_This project was start from the chapter 10 along with a basic react structure to a current well-organized and well-implemented app, whcih could user-friendly interact with any users on any devices,like our pc, laptop, and any type of smart phones, because it UI was designed in a responsive way_

## Link for se_project_react:

[github](https://github.com/IMLUOAI/se_project_react.git)
